import Adafruit_DHT
import time
import RPi.GPIO as GPIO
from firebase import firebase as firelib
from datetime import datetime
import adafruit_adxl34x
import busio
import board

DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4
DHT_REF_PIN = 7
PIR_OUT_PIN = 17    # pin11
GPIO_PIN_FLAME = 21    #flame
firebase = firelib.FirebaseApplication('https://home-automation-data-storage-default-rtdb.firebaseio.com/', None)
# datetime object containing current date and time
#now = datetime.now()

#i2c = busio.I2C(board.SCL, board.SDA)
i2c = board.I2C()
accelerometer = adafruit_adxl34x.ADXL345(i2c)
accelerometer.enable_freefall_detection(threshold=10, time=25)

accelerometer.enable_tap_detection(tap_count=1, threshold=10, duration=50, latency=20, window=255)

def printcust(text):
    print(text)

def setup():
# 	GPIO.setmode(GPIO.BOARD)
	GPIO.setup(DHT_REF_PIN, GPIO.IN)    # Set BtnPin's mode is input
	GPIO.setup(PIR_OUT_PIN, GPIO.IN)    # Set BtnPin's mode is input
	GPIO.setup(GPIO_PIN_FLAME, GPIO.IN)
# 	print("GPIOs setup")
	



def destroy():
# 	print('cleaning up GPIO pins')
	GPIO.cleanup()                     # Release resource
# 	print("done")


def firebaseecall(eventname):
   # time.sleep(1)
    firebase = firelib.FirebaseApplication('https://home-automation-data-storage-default-rtdb.firebaseio.com/', None)
    now = datetime.now()
    dt_string = now.strftime("%d-%m-%Y")
    tm_string = now.strftime("%H:%M:%S")
    tm_string1= now.strftime("%H%M%S")
#     print(tm_string)
    if ('temp' in eventname):
        data =  { 'Humidity-Temperature' : eventname}
        result = firebase.patch('/python-Aditya/'+ dt_string + '/' + 'Humidity-Temperature' ,data)
    else:    
        data =  { 'EventTime'+tm_string1 : tm_string}
        result = firebase.patch('/python-Aditya/'+ dt_string + str(eventname),data)
#     print(result)
    
    
    

def DHT11():
    
    humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
    if humidity is not None and temperature is not None:
#         print("temp={0:0.1f}c humidity={1:0.1f}%".format(temperature, humidity))
        temphum = 'temp - {0:0.1f}c humidity - {1:0.1f}'.format(temperature, humidity)
        print(temphum)
        firebaseecall(temphum)
        
    else:
        print();
        
def PIR():
     if GPIO.input(PIR_OUT_PIN) == GPIO.LOW:
         print ('...Movement not detected!')
         time.sleep(0.5)
     else:
        print ('Movement detected!...')
        time.sleep(0.5)

        
def accesslerometersensor():
    accelerometer.enable_motion_detection(threshold=21 )
    #print("%f %f %f"%accelerometer.acceleration)
    #print("Dropped: %s"%accelerometer.events["freefall"])
    print("Tapped: %s"%accelerometer.events['tap'])
    print("Motion detected: %s"%accelerometer.events['motion'])
#     time.sleep(0.5)
    if(accelerometer.events['motion'] == True):
        print("bang")
        firebaseecall('/Bang detected/')
        time.sleep(0.5);


def flame_detect(GPIOpin):
    if GPIO.input(GPIOpin) == GPIO.LOW:
        print ('...flame not detected!')
       # time.sleep(0.5)
    else:
        print ('flame detected...')
        firebaseecall('/Flame detected/')

def loop():
    
#     printcust("Checkup's started")
#     printcust("ignore first entry")
    
    while True:
        DHT11()
        PIR()
        accesslerometersensor()
        flame_detect(21)
        time.sleep(0.5);
        

if __name__ == '__main__':
    
	setup()
	printcust("all setups done")
	try:
		loop()
	except KeyboardInterrupt:
        
		destroy()
    



